#include "uart_task.h"
#include <ti/sysbios/BIOS.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/GPIO.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Event.h>
#include "string.h"
#include "Board.h"
#include "stdio.h"


#include <ti/drivers/PIN.h>
#include "C:\ti\simplelink_cc13x0_sdk_1_60_00_21\source\ti\devices\cc13x0\driverlib\sys_ctrl.h"

#include "easylink/EasyLink.h"

//#include DeviceFamily_constructPath(driverlib/sys_ctrl.h)

#define UART_EVENT_ALL                            0xFFFFFFFF
#define UART_EVENT_RESETSYSTEM                   (uint32_t)(1 << 0)
#define UART_EVENT_SENDMESSAGE                   (uint32_t)(1 << 1)


extern uint8_t RecvBuffer[100];
extern uint8_t Length;




//static Task_Params taskParams;
//Task_Struct uartTask;
//char uartTaskStack[512];


Event_Struct uartEvent;  /* Not static so you can see in ROV */
static Event_Handle uartEventHandle;


Task_Handle uartTask;

Event_Struct uartEvent;  /* not static so you can see in ROV */
static Event_Handle uartEventHandle;


static void UART_taskFxn(UArg a0, UArg a1);
void SendMessage2();
UART_Handle uart;
extern Semaphore_Handle rxDoneSem;

void uart_createTask(void)
{

    Event_Params eventParam;
    Event_Params_init(&eventParam);
    Event_construct(&uartEvent, &eventParam);
    uartEventHandle = Event_handle(&uartEvent);

    Task_Params params;
    Task_Params_init(&params);


    params.priority = 1;
    params.stackSize = 1024;


    uartTask = Task_create(UART_taskFxn,&params,0);
}


static void UART_taskFxn(UArg a0, UArg a1)
{
    char buffer[10];
    uint16_t tmp;
    UART_Params uartParams;
    GPIO_init();
    UART_init();
    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.readEcho = UART_ECHO_OFF;
    uartParams.baudRate = 115200;
    uart = UART_open(Board_UART0, &uartParams);
    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
    UART_write(uart, "INIT!\n", sizeof("INIT!\n"));
//    int rxBytes = UART_read(uart, Uart_RxBuf, wantedLen);
//    while(1)
//    {
//        Semaphore_pend(rxDoneSem,BIOS_WAIT_FOREVER);
//        memset(buffer,0,10);
//        tmp = mRadioStatus();
//        sprintf(buffer,"%X",tmp);
//        strcat(buffer,"\r\n");
//        UART_write(uart, buffer, 8);
////        Task_sleep(50000);
//
//    }
}

void SendUartEvent(char type)
{
  switch(type)
  {
  case Uart_Reset_Event:
    SysCtrlSystemReset();
    break;
  case Uart_Send_Event:
    SendMessage();
    break; 
  case Uart_Send_Event2:
      SendMessage2();
      break;
  }
}

void SendMessage2()
{
    char buffer[10];
    memset(buffer,0,10);
    sprintf(buffer,"%x",mRadioStatus());
    strcat(buffer,"X\r\n");
    UART_write(uart, buffer, 7);
}


void SendMessage()
{
//    char buffer[10];
//    memset(buffer,0,10);
//    sprintf(buffer,"%x",mRadioStatus());
//    strcat(buffer,"\r\n");
//    UART_write(uart, buffer, 6);
    UART_write(uart, RecvBuffer, Length);
    UART_write(uart, "\r\n", 2);
}
