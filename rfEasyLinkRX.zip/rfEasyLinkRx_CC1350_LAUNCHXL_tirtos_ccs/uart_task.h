#ifndef __UART_TASK_H__
#define __UART_TASK_H__


#include <ti/sysbios/knl/Task.h>



typedef enum{
  Uart_Reset_Event = 0,
  Uart_Send_Event,
  Uart_Send_Event2,
}mUartEvent;



void uart_createTask(void);
void SendMessage();
void SendUartEvent(char type);


extern Task_Handle uartTask;






#endif


